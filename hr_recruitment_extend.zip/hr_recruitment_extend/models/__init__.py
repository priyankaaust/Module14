'''
Created on Jun 15, 2022

@author: odoo
'''
from . import hr_contact
from . import hr_applicant