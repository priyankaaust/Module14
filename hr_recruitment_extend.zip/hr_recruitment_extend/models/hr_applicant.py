'''
Created on Jun 15, 2022

@author: odoo
'''
from odoo import api, fields, models
from odoo.exceptions import UserError
from odoo.tools.translate import _

class Applicant(models.Model):
    _inherit = "hr.applicant"
    
    contact_ids = fields.One2many('hr.contact', 'applicant_id', 'Contact')
    education_ids = fields.One2many('hr.education', 'applicant_id', 'Education')
    manager_id = fields.Many2one('hr.employee', 'Manager', compute="_compute_parent_id", store=True, readonly=False,
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]")
    
    @api.depends('department_id')
    def _compute_parent_id(self):
        for employee in self.filtered('department_id.manager_id'):
            employee.manager_id = employee.department_id.manager_id
            
    def create_employee_from_applicant(self):
        if not self.env.user.has_group ('hr.group_hr_manager'):
            raise UserError(_('Only HR Manager Is Allowed To Create Employee.'))
        res =  super(Applicant, self).create_employee_from_applicant()
        #print(res.id)
        #print(res["context"]) 
        for applicant in self:
            res["context"]['default_contact_ids']= [m['id'] for m in applicant.contact_ids]
            res["context"]['default_education_ids']= [m['id'] for m in applicant.education_ids]
        return res
    
    
class HrEmployee(models.Model):
    _inherit = "hr.employee"
    
    contact_ids = fields.One2many('hr.contact', 'emp_id', 'Contact')
    education_ids = fields.One2many('hr.education', 'emp_id', 'Education')
    holiday_ids = fields.One2many('hr.leave', 'employee_id', 'Leave Details')
    
    