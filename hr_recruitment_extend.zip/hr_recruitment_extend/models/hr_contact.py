'''
Created on Jun 15, 2022

@author: odoo
'''
from odoo import api, fields, models, tools, SUPERUSER_ID
from odoo.tools.translate import _
from odoo.exceptions import UserError

class Contact(models.Model):
    _name = "hr.contact"
    _description = "Contact"
    
    name = fields.Char("Name", required=True)
    contact_phone = fields.Char("Phone")
    contact_address = fields.Char("Address")
    applicant_id = fields.Many2one('hr.applicant', "Applicant")
    emp_id = fields.Many2one('hr.employee', string="Employee", copy=False)
    
class Education(models.Model):
    _name = "hr.education"
    _description = "Education"
    
    degree = fields.Char("Degree", required=True)
    institute = fields.Char("Institute", required=True)
    passing_year = fields.Char("Passing Year")
    applicant_id = fields.Many2one('hr.applicant', "Applicant")
    emp_id = fields.Many2one('hr.employee', string="Employee", copy=False)

