EXTEND ODOO RECRUITMENT AND EMPLOYEE
-------------------


A.Recruitment Flow Extension in Applicant Form
1. Multiple Emergency Contact Informations Lines collecting below information
a. Name
b. Address
c. Phone
2. Multiple Education lines collecting below information
a. Institute
b. Degree
c. Passing Year
3. Assign Manager
-- All above informations should be saved in Employee model (At least one line of each)
-- Only a role of Group: HR Managers can “Create Employee” after providing required
information
--All Above Informations Shall be carry forwarded and saved to Employee Model
B.Access Control
1. Departments Managers only gets to see recruitment applications of their own
department only
C. Assign Leave when creating Employee from Recruitment
1. Select Leave Type(Single)
2. Fill Leave Days
a. Allocate Leave for the current year only
--Leave days must be assigned when creating Employee
