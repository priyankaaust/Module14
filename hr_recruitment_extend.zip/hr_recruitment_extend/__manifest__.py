# -*- coding: utf-8 -*-
{
    'name': "Hr Recruitment Extension",
    'version': '1.0',
    'category': 'Human Resources',
    'summary': 'EXTEND ODOO RECRUITMENT AND EMPLOYEE',
    'description': """
        Use interview forms during recruitment process.
        This module is integrated with the recruitment module
        to allow you to define Contacts and educational information.
    """,
    'depends': ['hr_recruitment','hr_holidays'],
    'data': [
        'security/ir.model.access.csv',
        'views/hr_applicant_views.xml',
    ],
    'demo': [
        
    ],
    'auto_install': False,
}
